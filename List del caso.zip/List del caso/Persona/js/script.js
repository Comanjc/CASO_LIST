var listar = 'http://localhost:9192/persona';
var agregar = 'http://localhost:9192/api/persona/save';
var Eliminar = 'http://localhost:9192/api/persona/del/{id}';

$(document).ready(function () {
    cargaDatosPersona();
   

});


function cargaDatosPersona() {

    $.ajax({
        url: listar,
        type: "GET",
        datatype: "JSON",
        success: function (respuesta) {
            var myItems = respuesta;
            var valor = '';
            for (i = 0; i < myItems.length; i++) {
                valor +=
                    '<tr>' +
                    '<td>' + myItems[i].id + '</td>' +
                    '<td>' + myItems[i].nif + '</td>' +
                    '<td>' + myItems[i].nombre + '</td>' +
                    '<td>' + myItems[i].apellido1 + '</td>' +
                    '<td>' + myItems[i].apellido2 + '</td>' +
                    '<td>' + myItems[i].ciudad + '</td>' +
                    '<td>' + myItems[i].direccion + '</td>' +
                    '<td>' + myItems[i].telefono + '</td>' +
                    '<td>' + myItems[i].fecha_nacimiento + '</td>'+
                    '<td>' + myItems[i].sexo + '</td>' +
                    '<td>' + myItems[i].tipo + '</td>' +
                    '<td>' +
                    ' <button class="btn btn-danger" onclick="borrarPersona(' + myItems[i].id + ')">Eliminar</button>' +
                    '<button class="btn btn-primary  ms-3" onclick="detallesPersona(' + myItems[i].id + ')">Editar</button>' +

                    '</td>' +
                    '</tr > ';


            }
            $('#tbodyPersona').html(valor);
        }

    })
}
function crearPersona() {
  /*  var datosp = {};
    $('#btnCrear').click(function(){
        datosp.id= $('#idper').val();
        datosp.nif= $('#nif').val();
        datosp.nombre= $('#nombre').val();
        datosp.apellido1=$('#apellido1').val();
        datosp.apellido2= $('#apellido2').val();
        datosp.ciudad= $('#ciudad').val();
        datosp.direccion= $('#direccion').val();
        datosp.telefono= $('#telefono').val();
        datosp.fecha_nacimiento= $('#fecha_nacimiento').val();
        datosp.sexo= $('#sexo').val();
        datosp.tipo= $('#tipo').val();
        var datospObj = JSON.stringify(datosp);
        $.ajax({
            url:agregar,
            method: 'POST',
            data: datospObj,
            contentType: "application/json; charset = utf-8",
            success: function(){
                alert('registrado');
            },
            error: function(error){
                alert(error);
            }
        })
    })
    alert(datospObj);
*/

    var datosPersona = {

        id: $('#idper').val(),
        nif: $('#nif').val(),
        nombre: $('#nombre').val(),
        apellido1: $('#apellido1').val(),
        apellido2: $('#apellido2').val(),
        ciudad: $('#ciudad').val(),
        direccion: $('#direccion').val(),
        telefono: $('#telefono').val(),
        fecha_nacimiento: $('#fecha_nacimiento').val(),
        sexo: $('#sexo').val(),
        tipo: $('#tipo').val()

    };


    var datosPersonaJson = JSON.stringify(datosPersona);

    $.ajax({

        url: agregar,
        type: "POST",
        data: datosPersonaJson,
        datatype: "JSON",
        contentType: "application/json",
        success: function (respuesta) {
            console.log(respuesta);
            cargaDatosPersona();


        }

    });
    alert(datosPersonaJson);

}
function borrarPersona(idpersona){
    var datosPersona = {

        id: idpersona

    };
    var datosPersonaJson = JSON.stringify(datosPersona);
    $.ajax({

        url: Eliminar,
        type: "DELETE",
        data: datosPersonaJson,
        datatype: "JSON",
        contentType: "application/json",
        success: function (respuesta) {
            console.log(respuesta);


        }

    });


}